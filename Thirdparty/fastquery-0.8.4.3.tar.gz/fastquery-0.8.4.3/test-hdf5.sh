#!/bin/sh
rm -f examples/test.h5 examples/test-index.h5 
#(cd examples && make -j 2 nompi)
if [ $# -ge 1 ]; then
    V=$1
else
    V=0
fi
if [ $# -ge 2 ]; then
    G="-g $2"
else
    G=""
fi
if [ $V -gt 1 ]; then
    set -x
fi
./examples/read -f examples/h5uc-data.h5 -n px -p TimeStep1 -v $V $G
./examples/read -f examples/h5uc-data.h5 -n "px[0:10]" -p TimeStep1 -v $V $G
./examples/writeData -f examples/test.h5 -i examples/test.dat -n x -p "/time1" -d "5:15:17" -t double -c -v $V $G
./examples/writeData -f examples/test.h5 -i examples/test.dat -n x -p "/" -d "25:51" -t int -c -v $V $G
./examples/writeAttr -f examples/test.h5 -i examples/test.dat -n x -p "/time1" -a "attr" -l 2 -t int -c -v $V $G
./examples/buildIndex -f examples/test.h5 -i examples/test-index.h5 -r -l 2 -v $V $G
./examples/queryIndex -f examples/test.h5 -i examples/test-index.h5 -q "x>3 && x<8" -n x -p time1 -l 2 -v $V $G
./examples/queryIndex -f examples/test.h5 -i examples/test-index.h5 -q "x>3 && x<8" -n x -p time1 -l 2 -b -v $V $G
./examples/histogram -x 1 -y 2 -e 9 -s 2 -f examples/test.h5 -i examples/test-index.h5 -q "x>1 && x<10" -n x -p time1 -l 2 -v $V $G
#rm examples/test.h5 examples/test-index.h5
