# Visit 2.7.0b log file
ScriptVersion = "2.7.0b"
if ScriptVersion != Version():
    print "This script is for VisIt %s. It may not work with version %s" % (ScriptVersion, Version())
ShowAllWindows()
OpenDatabase("m_plot.plt.mili", 0)
# The UpdateDBPluginInfo RPC is not supported in the VisIt module so it will not be logged.
